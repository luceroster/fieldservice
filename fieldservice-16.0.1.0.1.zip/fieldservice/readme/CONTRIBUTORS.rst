* Wolfgang Hall <whall@opensourceintegrators.com>
* Maxime Chambreuil <mchambreuil@opensourceintegrators.com>
* Steve Campbell <scampbell@opensourceintegrators.com>
* Bhavesh Odedra <bodedra@opensourceintegrators.com>
* Michael Allen <mallen@opensourceintegrators.com>
* Sandip Mangukiya <smangukiya@opensourceintegrators.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Brian McMaster <brian@mcmpest.com>
* Raphaël Reverdy <raphael.reverdy@akretion.com>
* Ammar Officewala <ammar.o.serpentcs@gmail.com>
* Yves Goldberg <yves@ygol.com>
* Freni Patel <fpatel@opensourceintegrators.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
